from platonics import dodeca

dode_face_main(10,1)
