import mid_pt
import tetr_face_COM_coord


def tetr_face_COM_leg_coord(a: float, b: float, c: float):
    COM_leg = []
    COM_leg.append(tetr_face_COM_coord(a, b, c))
    COM_leg.append(mid_pt(a, b))
    COM_leg.append(mid_pt(b, c))
    COM_leg.append(mid_pt(c, a))
    return COM_leg


